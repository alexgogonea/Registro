﻿namespace Registro
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtClasse = new System.Windows.Forms.TextBox();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Aggiungi = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_Leggi = new System.Windows.Forms.Button();
            this.btn_Salva = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Txt_Cognome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtMatricola = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TxtData = new System.Windows.Forms.TextBox();
            this.Italiano = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.comboBoxIta5 = new System.Windows.Forms.ComboBox();
            this.comboBoxIta4 = new System.Windows.Forms.ComboBox();
            this.comboBoxIta3 = new System.Windows.Forms.ComboBox();
            this.comboBoxIta2 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBoxIta1 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.comboBoxSto2 = new System.Windows.Forms.ComboBox();
            this.comboBoxSto3 = new System.Windows.Forms.ComboBox();
            this.comboBoxSto4 = new System.Windows.Forms.ComboBox();
            this.comboBoxSto5 = new System.Windows.Forms.ComboBox();
            this.comboBoxSto1 = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBoxMate2 = new System.Windows.Forms.ComboBox();
            this.comboBoxMate3 = new System.Windows.Forms.ComboBox();
            this.comboBoxMate4 = new System.Windows.Forms.ComboBox();
            this.comboBoxMate5 = new System.Windows.Forms.ComboBox();
            this.comboBoxMate1 = new System.Windows.Forms.ComboBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.comboBoxIng5 = new System.Windows.Forms.ComboBox();
            this.comboBoxIng4 = new System.Windows.Forms.ComboBox();
            this.comboBoxIng3 = new System.Windows.Forms.ComboBox();
            this.comboBoxIng2 = new System.Windows.Forms.ComboBox();
            this.comboBoxIng1 = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.comboBoxInfo5 = new System.Windows.Forms.ComboBox();
            this.comboBoxInfo4 = new System.Windows.Forms.ComboBox();
            this.comboBoxInfo3 = new System.Windows.Forms.ComboBox();
            this.comboBoxInfo2 = new System.Windows.Forms.ComboBox();
            this.comboBoxInfo1 = new System.Windows.Forms.ComboBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.comboBoxSis5 = new System.Windows.Forms.ComboBox();
            this.comboBoxSis4 = new System.Windows.Forms.ComboBox();
            this.comboBoxSis3 = new System.Windows.Forms.ComboBox();
            this.comboBoxSis2 = new System.Windows.Forms.ComboBox();
            this.comboBoxSis1 = new System.Windows.Forms.ComboBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.comboBoxTPSIT5 = new System.Windows.Forms.ComboBox();
            this.comboBoxTPSIT4 = new System.Windows.Forms.ComboBox();
            this.comboBoxTPSIT3 = new System.Windows.Forms.ComboBox();
            this.comboBoxTPSIT2 = new System.Windows.Forms.ComboBox();
            this.comboBoxTPSIT1 = new System.Windows.Forms.ComboBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.comboBoxTele5 = new System.Windows.Forms.ComboBox();
            this.comboBoxTele4 = new System.Windows.Forms.ComboBox();
            this.comboBoxTele3 = new System.Windows.Forms.ComboBox();
            this.comboBoxTele2 = new System.Windows.Forms.ComboBox();
            this.comboBoxTele1 = new System.Windows.Forms.ComboBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.btn_Cancella = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.Italiano.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.SuspendLayout();
            // 
            // TxtClasse
            // 
            this.TxtClasse.Location = new System.Drawing.Point(1077, 169);
            this.TxtClasse.Name = "TxtClasse";
            this.TxtClasse.Size = new System.Drawing.Size(134, 22);
            this.TxtClasse.TabIndex = 18;
            // 
            // TxtNome
            // 
            this.TxtNome.Location = new System.Drawing.Point(1077, 82);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(192, 22);
            this.TxtNome.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(907, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 42);
            this.label3.TabIndex = 15;
            this.label3.Text = "Classe";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(907, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 42);
            this.label1.TabIndex = 13;
            this.label1.Text = "Nome";
            // 
            // btn_Aggiungi
            // 
            this.btn_Aggiungi.Location = new System.Drawing.Point(953, 623);
            this.btn_Aggiungi.Name = "btn_Aggiungi";
            this.btn_Aggiungi.Size = new System.Drawing.Size(200, 52);
            this.btn_Aggiungi.TabIndex = 12;
            this.btn_Aggiungi.Text = "Aggiorna";
            this.btn_Aggiungi.UseVisualStyleBackColor = true;
            this.btn_Aggiungi.Click += new System.EventHandler(this.btn_Aggiungi_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeight = 29;
            this.dataGridView1.Location = new System.Drawing.Point(6, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(879, 567);
            this.dataGridView1.TabIndex = 28;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // btn_Leggi
            // 
            this.btn_Leggi.Location = new System.Drawing.Point(218, 623);
            this.btn_Leggi.Name = "btn_Leggi";
            this.btn_Leggi.Size = new System.Drawing.Size(200, 52);
            this.btn_Leggi.TabIndex = 22;
            this.btn_Leggi.Text = "Leggi";
            this.btn_Leggi.UseVisualStyleBackColor = true;
            this.btn_Leggi.Click += new System.EventHandler(this.btn_Leggi_Click);
            // 
            // btn_Salva
            // 
            this.btn_Salva.Location = new System.Drawing.Point(12, 623);
            this.btn_Salva.Name = "btn_Salva";
            this.btn_Salva.Size = new System.Drawing.Size(200, 52);
            this.btn_Salva.TabIndex = 23;
            this.btn_Salva.Text = "Salva";
            this.btn_Salva.UseVisualStyleBackColor = true;
            this.btn_Salva.Click += new System.EventHandler(this.btn_Salva_Click);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(907, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 42);
            this.label5.TabIndex = 24;
            this.label5.Text = "Cognome";
            // 
            // Txt_Cognome
            // 
            this.Txt_Cognome.Location = new System.Drawing.Point(1077, 127);
            this.Txt_Cognome.Name = "Txt_Cognome";
            this.Txt_Cognome.Size = new System.Drawing.Size(192, 22);
            this.Txt_Cognome.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(908, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 42);
            this.label2.TabIndex = 29;
            this.label2.Text = "Matricola";
            // 
            // TxtMatricola
            // 
            this.TxtMatricola.Location = new System.Drawing.Point(1077, 40);
            this.TxtMatricola.Name = "TxtMatricola";
            this.TxtMatricola.Size = new System.Drawing.Size(134, 22);
            this.TxtMatricola.TabIndex = 30;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(908, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 42);
            this.label4.TabIndex = 31;
            this.label4.Text = "Data di Nascita";
            // 
            // TxtData
            // 
            this.TxtData.Location = new System.Drawing.Point(1077, 215);
            this.TxtData.Name = "TxtData";
            this.TxtData.Size = new System.Drawing.Size(134, 22);
            this.TxtData.TabIndex = 32;
            // 
            // Italiano
            // 
            this.Italiano.Controls.Add(this.tabPage1);
            this.Italiano.Controls.Add(this.tabPage2);
            this.Italiano.Controls.Add(this.tabPage3);
            this.Italiano.Controls.Add(this.tabPage4);
            this.Italiano.Controls.Add(this.tabPage5);
            this.Italiano.Controls.Add(this.tabPage6);
            this.Italiano.Controls.Add(this.tabPage7);
            this.Italiano.Controls.Add(this.tabPage8);
            this.Italiano.Location = new System.Drawing.Point(913, 294);
            this.Italiano.Name = "Italiano";
            this.Italiano.SelectedIndex = 0;
            this.Italiano.Size = new System.Drawing.Size(542, 319);
            this.Italiano.TabIndex = 33;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.comboBoxIta5);
            this.tabPage1.Controls.Add(this.comboBoxIta4);
            this.tabPage1.Controls.Add(this.comboBoxIta3);
            this.tabPage1.Controls.Add(this.comboBoxIta2);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.comboBoxIta1);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(534, 290);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Italiano";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // comboBoxIta5
            // 
            this.comboBoxIta5.FormattingEnabled = true;
            this.comboBoxIta5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxIta5.Location = new System.Drawing.Point(87, 188);
            this.comboBoxIta5.Name = "comboBoxIta5";
            this.comboBoxIta5.Size = new System.Drawing.Size(121, 24);
            this.comboBoxIta5.TabIndex = 43;
            this.comboBoxIta5.Text = "0";
            // 
            // comboBoxIta4
            // 
            this.comboBoxIta4.FormattingEnabled = true;
            this.comboBoxIta4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxIta4.Location = new System.Drawing.Point(87, 149);
            this.comboBoxIta4.Name = "comboBoxIta4";
            this.comboBoxIta4.Size = new System.Drawing.Size(121, 24);
            this.comboBoxIta4.TabIndex = 42;
            this.comboBoxIta4.Text = "0";
            // 
            // comboBoxIta3
            // 
            this.comboBoxIta3.FormattingEnabled = true;
            this.comboBoxIta3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxIta3.Location = new System.Drawing.Point(87, 107);
            this.comboBoxIta3.Name = "comboBoxIta3";
            this.comboBoxIta3.Size = new System.Drawing.Size(121, 24);
            this.comboBoxIta3.TabIndex = 41;
            this.comboBoxIta3.Text = "0";
            // 
            // comboBoxIta2
            // 
            this.comboBoxIta2.FormattingEnabled = true;
            this.comboBoxIta2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxIta2.Location = new System.Drawing.Point(87, 67);
            this.comboBoxIta2.Name = "comboBoxIta2";
            this.comboBoxIta2.Size = new System.Drawing.Size(121, 24);
            this.comboBoxIta2.TabIndex = 40;
            this.comboBoxIta2.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 188);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 25);
            this.label10.TabIndex = 39;
            this.label10.Text = "Voto 5";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 149);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 25);
            this.label9.TabIndex = 38;
            this.label9.Text = "Voto 4";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 107);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 25);
            this.label8.TabIndex = 37;
            this.label8.Text = "Voto 3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 25);
            this.label7.TabIndex = 36;
            this.label7.Text = "Voto 2";
            // 
            // comboBoxIta1
            // 
            this.comboBoxIta1.FormattingEnabled = true;
            this.comboBoxIta1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxIta1.Location = new System.Drawing.Point(87, 23);
            this.comboBoxIta1.Name = "comboBoxIta1";
            this.comboBoxIta1.Size = new System.Drawing.Size(121, 24);
            this.comboBoxIta1.TabIndex = 35;
            this.comboBoxIta1.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 25);
            this.label6.TabIndex = 34;
            this.label6.Text = "Voto 1";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.comboBoxSto2);
            this.tabPage2.Controls.Add(this.comboBoxSto3);
            this.tabPage2.Controls.Add(this.comboBoxSto4);
            this.tabPage2.Controls.Add(this.comboBoxSto5);
            this.tabPage2.Controls.Add(this.comboBoxSto1);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(534, 290);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Storia";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // comboBoxSto2
            // 
            this.comboBoxSto2.FormattingEnabled = true;
            this.comboBoxSto2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxSto2.Location = new System.Drawing.Point(87, 57);
            this.comboBoxSto2.Name = "comboBoxSto2";
            this.comboBoxSto2.Size = new System.Drawing.Size(121, 24);
            this.comboBoxSto2.TabIndex = 9;
            this.comboBoxSto2.Text = "0";
            // 
            // comboBoxSto3
            // 
            this.comboBoxSto3.FormattingEnabled = true;
            this.comboBoxSto3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxSto3.Location = new System.Drawing.Point(87, 99);
            this.comboBoxSto3.Name = "comboBoxSto3";
            this.comboBoxSto3.Size = new System.Drawing.Size(121, 24);
            this.comboBoxSto3.TabIndex = 8;
            this.comboBoxSto3.Text = "0";
            // 
            // comboBoxSto4
            // 
            this.comboBoxSto4.FormattingEnabled = true;
            this.comboBoxSto4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxSto4.Location = new System.Drawing.Point(87, 141);
            this.comboBoxSto4.Name = "comboBoxSto4";
            this.comboBoxSto4.Size = new System.Drawing.Size(121, 24);
            this.comboBoxSto4.TabIndex = 7;
            this.comboBoxSto4.Text = "0";
            // 
            // comboBoxSto5
            // 
            this.comboBoxSto5.FormattingEnabled = true;
            this.comboBoxSto5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxSto5.Location = new System.Drawing.Point(87, 184);
            this.comboBoxSto5.Name = "comboBoxSto5";
            this.comboBoxSto5.Size = new System.Drawing.Size(121, 24);
            this.comboBoxSto5.TabIndex = 6;
            this.comboBoxSto5.Text = "0";
            // 
            // comboBoxSto1
            // 
            this.comboBoxSto1.FormattingEnabled = true;
            this.comboBoxSto1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxSto1.Location = new System.Drawing.Point(87, 16);
            this.comboBoxSto1.Name = "comboBoxSto1";
            this.comboBoxSto1.Size = new System.Drawing.Size(121, 24);
            this.comboBoxSto1.TabIndex = 5;
            this.comboBoxSto1.Text = "0";
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(3, 137);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(78, 23);
            this.label15.TabIndex = 4;
            this.label15.Text = "Voto 4";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(3, 180);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 37);
            this.label14.TabIndex = 3;
            this.label14.Text = "Voto 5";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 95);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 23);
            this.label13.TabIndex = 2;
            this.label13.Text = "Voto 3";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 53);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 23);
            this.label12.TabIndex = 1;
            this.label12.Text = "Voto 2";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 12);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 23);
            this.label11.TabIndex = 0;
            this.label11.Text = "Voto 1";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.comboBoxMate2);
            this.tabPage3.Controls.Add(this.comboBoxMate3);
            this.tabPage3.Controls.Add(this.comboBoxMate4);
            this.tabPage3.Controls.Add(this.comboBoxMate5);
            this.tabPage3.Controls.Add(this.comboBoxMate1);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(534, 290);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Matematica";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(12, 108);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 25);
            this.label20.TabIndex = 9;
            this.label20.Text = "Voto 3";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(12, 150);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(69, 25);
            this.label19.TabIndex = 8;
            this.label19.Text = "Voto 4";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(12, 194);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 25);
            this.label18.TabIndex = 7;
            this.label18.Text = "Voto 5";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(12, 66);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 25);
            this.label17.TabIndex = 6;
            this.label17.Text = "Voto 2";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(12, 24);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 25);
            this.label16.TabIndex = 5;
            this.label16.Text = "Voto 1";
            // 
            // comboBoxMate2
            // 
            this.comboBoxMate2.FormattingEnabled = true;
            this.comboBoxMate2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxMate2.Location = new System.Drawing.Point(87, 67);
            this.comboBoxMate2.Name = "comboBoxMate2";
            this.comboBoxMate2.Size = new System.Drawing.Size(121, 24);
            this.comboBoxMate2.TabIndex = 4;
            this.comboBoxMate2.Text = "0";
            // 
            // comboBoxMate3
            // 
            this.comboBoxMate3.FormattingEnabled = true;
            this.comboBoxMate3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxMate3.Location = new System.Drawing.Point(87, 109);
            this.comboBoxMate3.Name = "comboBoxMate3";
            this.comboBoxMate3.Size = new System.Drawing.Size(121, 24);
            this.comboBoxMate3.TabIndex = 3;
            this.comboBoxMate3.Text = "0";
            // 
            // comboBoxMate4
            // 
            this.comboBoxMate4.FormattingEnabled = true;
            this.comboBoxMate4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxMate4.Location = new System.Drawing.Point(87, 154);
            this.comboBoxMate4.Name = "comboBoxMate4";
            this.comboBoxMate4.Size = new System.Drawing.Size(121, 24);
            this.comboBoxMate4.TabIndex = 2;
            this.comboBoxMate4.Text = "0";
            // 
            // comboBoxMate5
            // 
            this.comboBoxMate5.FormattingEnabled = true;
            this.comboBoxMate5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxMate5.Location = new System.Drawing.Point(87, 194);
            this.comboBoxMate5.Name = "comboBoxMate5";
            this.comboBoxMate5.Size = new System.Drawing.Size(121, 24);
            this.comboBoxMate5.TabIndex = 1;
            this.comboBoxMate5.Text = "0";
            // 
            // comboBoxMate1
            // 
            this.comboBoxMate1.FormattingEnabled = true;
            this.comboBoxMate1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxMate1.Location = new System.Drawing.Point(87, 25);
            this.comboBoxMate1.Name = "comboBoxMate1";
            this.comboBoxMate1.Size = new System.Drawing.Size(121, 24);
            this.comboBoxMate1.TabIndex = 0;
            this.comboBoxMate1.Text = "0";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.comboBoxIng5);
            this.tabPage4.Controls.Add(this.comboBoxIng4);
            this.tabPage4.Controls.Add(this.comboBoxIng3);
            this.tabPage4.Controls.Add(this.comboBoxIng2);
            this.tabPage4.Controls.Add(this.comboBoxIng1);
            this.tabPage4.Controls.Add(this.label25);
            this.tabPage4.Controls.Add(this.label24);
            this.tabPage4.Controls.Add(this.label23);
            this.tabPage4.Controls.Add(this.label22);
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(534, 290);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Inglese";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // comboBoxIng5
            // 
            this.comboBoxIng5.FormattingEnabled = true;
            this.comboBoxIng5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxIng5.Location = new System.Drawing.Point(87, 177);
            this.comboBoxIng5.Name = "comboBoxIng5";
            this.comboBoxIng5.Size = new System.Drawing.Size(121, 24);
            this.comboBoxIng5.TabIndex = 9;
            this.comboBoxIng5.Text = "0";
            // 
            // comboBoxIng4
            // 
            this.comboBoxIng4.FormattingEnabled = true;
            this.comboBoxIng4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxIng4.Location = new System.Drawing.Point(87, 136);
            this.comboBoxIng4.Name = "comboBoxIng4";
            this.comboBoxIng4.Size = new System.Drawing.Size(121, 24);
            this.comboBoxIng4.TabIndex = 8;
            this.comboBoxIng4.Text = "0";
            // 
            // comboBoxIng3
            // 
            this.comboBoxIng3.FormattingEnabled = true;
            this.comboBoxIng3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxIng3.Location = new System.Drawing.Point(87, 94);
            this.comboBoxIng3.Name = "comboBoxIng3";
            this.comboBoxIng3.Size = new System.Drawing.Size(121, 24);
            this.comboBoxIng3.TabIndex = 7;
            this.comboBoxIng3.Text = "0";
            // 
            // comboBoxIng2
            // 
            this.comboBoxIng2.FormattingEnabled = true;
            this.comboBoxIng2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxIng2.Location = new System.Drawing.Point(87, 59);
            this.comboBoxIng2.Name = "comboBoxIng2";
            this.comboBoxIng2.Size = new System.Drawing.Size(121, 24);
            this.comboBoxIng2.TabIndex = 6;
            this.comboBoxIng2.Text = "0";
            // 
            // comboBoxIng1
            // 
            this.comboBoxIng1.FormattingEnabled = true;
            this.comboBoxIng1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxIng1.Location = new System.Drawing.Point(87, 17);
            this.comboBoxIng1.Name = "comboBoxIng1";
            this.comboBoxIng1.Size = new System.Drawing.Size(121, 24);
            this.comboBoxIng1.TabIndex = 5;
            this.comboBoxIng1.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(12, 176);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(69, 25);
            this.label25.TabIndex = 4;
            this.label25.Text = "Voto 5";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(12, 135);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(69, 25);
            this.label24.TabIndex = 3;
            this.label24.Text = "Voto 4";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(12, 94);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(69, 25);
            this.label23.TabIndex = 2;
            this.label23.Text = "Voto 3";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(12, 55);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(69, 25);
            this.label22.TabIndex = 1;
            this.label22.Text = "Voto 2";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(12, 17);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(69, 25);
            this.label21.TabIndex = 0;
            this.label21.Text = "Voto 1";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label30);
            this.tabPage5.Controls.Add(this.label29);
            this.tabPage5.Controls.Add(this.label28);
            this.tabPage5.Controls.Add(this.label27);
            this.tabPage5.Controls.Add(this.label26);
            this.tabPage5.Controls.Add(this.comboBoxInfo5);
            this.tabPage5.Controls.Add(this.comboBoxInfo4);
            this.tabPage5.Controls.Add(this.comboBoxInfo3);
            this.tabPage5.Controls.Add(this.comboBoxInfo2);
            this.tabPage5.Controls.Add(this.comboBoxInfo1);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(534, 290);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Informatica";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(3, 66);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(69, 25);
            this.label30.TabIndex = 9;
            this.label30.Text = "Voto 2";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(3, 110);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(69, 25);
            this.label29.TabIndex = 8;
            this.label29.Text = "Voto 3";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(3, 151);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(69, 25);
            this.label28.TabIndex = 7;
            this.label28.Text = "Voto 4";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(3, 192);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(69, 25);
            this.label27.TabIndex = 6;
            this.label27.Text = "Voto 5";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(3, 22);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(69, 25);
            this.label26.TabIndex = 5;
            this.label26.Text = "Voto 1";
            // 
            // comboBoxInfo5
            // 
            this.comboBoxInfo5.FormattingEnabled = true;
            this.comboBoxInfo5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxInfo5.Location = new System.Drawing.Point(78, 192);
            this.comboBoxInfo5.Name = "comboBoxInfo5";
            this.comboBoxInfo5.Size = new System.Drawing.Size(121, 24);
            this.comboBoxInfo5.TabIndex = 4;
            this.comboBoxInfo5.Text = "0";
            // 
            // comboBoxInfo4
            // 
            this.comboBoxInfo4.FormattingEnabled = true;
            this.comboBoxInfo4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxInfo4.Location = new System.Drawing.Point(78, 151);
            this.comboBoxInfo4.Name = "comboBoxInfo4";
            this.comboBoxInfo4.Size = new System.Drawing.Size(121, 24);
            this.comboBoxInfo4.TabIndex = 3;
            this.comboBoxInfo4.Text = "0";
            // 
            // comboBoxInfo3
            // 
            this.comboBoxInfo3.FormattingEnabled = true;
            this.comboBoxInfo3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxInfo3.Location = new System.Drawing.Point(78, 110);
            this.comboBoxInfo3.Name = "comboBoxInfo3";
            this.comboBoxInfo3.Size = new System.Drawing.Size(121, 24);
            this.comboBoxInfo3.TabIndex = 2;
            this.comboBoxInfo3.Text = "0";
            // 
            // comboBoxInfo2
            // 
            this.comboBoxInfo2.FormattingEnabled = true;
            this.comboBoxInfo2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxInfo2.Location = new System.Drawing.Point(78, 66);
            this.comboBoxInfo2.Name = "comboBoxInfo2";
            this.comboBoxInfo2.Size = new System.Drawing.Size(121, 24);
            this.comboBoxInfo2.TabIndex = 1;
            this.comboBoxInfo2.Text = "0";
            // 
            // comboBoxInfo1
            // 
            this.comboBoxInfo1.FormattingEnabled = true;
            this.comboBoxInfo1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxInfo1.Location = new System.Drawing.Point(78, 23);
            this.comboBoxInfo1.Name = "comboBoxInfo1";
            this.comboBoxInfo1.Size = new System.Drawing.Size(121, 24);
            this.comboBoxInfo1.TabIndex = 0;
            this.comboBoxInfo1.Text = "0";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.label35);
            this.tabPage6.Controls.Add(this.label34);
            this.tabPage6.Controls.Add(this.label33);
            this.tabPage6.Controls.Add(this.label32);
            this.tabPage6.Controls.Add(this.label31);
            this.tabPage6.Controls.Add(this.comboBoxSis5);
            this.tabPage6.Controls.Add(this.comboBoxSis4);
            this.tabPage6.Controls.Add(this.comboBoxSis3);
            this.tabPage6.Controls.Add(this.comboBoxSis2);
            this.tabPage6.Controls.Add(this.comboBoxSis1);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(534, 290);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Sistemi e reti";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(3, 68);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(69, 25);
            this.label35.TabIndex = 9;
            this.label35.Text = "Voto 2";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(3, 106);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(69, 25);
            this.label34.TabIndex = 8;
            this.label34.Text = "Voto 3";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(3, 149);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(69, 25);
            this.label33.TabIndex = 7;
            this.label33.Text = "Voto 4";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(3, 188);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(69, 25);
            this.label32.TabIndex = 6;
            this.label32.Text = "Voto 5";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(3, 25);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(69, 25);
            this.label31.TabIndex = 5;
            this.label31.Text = "Voto 1";
            // 
            // comboBoxSis5
            // 
            this.comboBoxSis5.FormattingEnabled = true;
            this.comboBoxSis5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxSis5.Location = new System.Drawing.Point(78, 188);
            this.comboBoxSis5.Name = "comboBoxSis5";
            this.comboBoxSis5.Size = new System.Drawing.Size(121, 24);
            this.comboBoxSis5.TabIndex = 4;
            this.comboBoxSis5.Text = "0";
            // 
            // comboBoxSis4
            // 
            this.comboBoxSis4.FormattingEnabled = true;
            this.comboBoxSis4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxSis4.Location = new System.Drawing.Point(78, 149);
            this.comboBoxSis4.Name = "comboBoxSis4";
            this.comboBoxSis4.Size = new System.Drawing.Size(121, 24);
            this.comboBoxSis4.TabIndex = 3;
            this.comboBoxSis4.Text = "0";
            // 
            // comboBoxSis3
            // 
            this.comboBoxSis3.FormattingEnabled = true;
            this.comboBoxSis3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxSis3.Location = new System.Drawing.Point(78, 106);
            this.comboBoxSis3.Name = "comboBoxSis3";
            this.comboBoxSis3.Size = new System.Drawing.Size(121, 24);
            this.comboBoxSis3.TabIndex = 2;
            this.comboBoxSis3.Text = "0";
            // 
            // comboBoxSis2
            // 
            this.comboBoxSis2.FormattingEnabled = true;
            this.comboBoxSis2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxSis2.Location = new System.Drawing.Point(78, 68);
            this.comboBoxSis2.Name = "comboBoxSis2";
            this.comboBoxSis2.Size = new System.Drawing.Size(121, 24);
            this.comboBoxSis2.TabIndex = 1;
            this.comboBoxSis2.Text = "0";
            // 
            // comboBoxSis1
            // 
            this.comboBoxSis1.FormattingEnabled = true;
            this.comboBoxSis1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxSis1.Location = new System.Drawing.Point(78, 25);
            this.comboBoxSis1.Name = "comboBoxSis1";
            this.comboBoxSis1.Size = new System.Drawing.Size(121, 24);
            this.comboBoxSis1.TabIndex = 0;
            this.comboBoxSis1.Text = "0";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.label40);
            this.tabPage7.Controls.Add(this.label39);
            this.tabPage7.Controls.Add(this.label38);
            this.tabPage7.Controls.Add(this.label37);
            this.tabPage7.Controls.Add(this.label36);
            this.tabPage7.Controls.Add(this.comboBoxTPSIT5);
            this.tabPage7.Controls.Add(this.comboBoxTPSIT4);
            this.tabPage7.Controls.Add(this.comboBoxTPSIT3);
            this.tabPage7.Controls.Add(this.comboBoxTPSIT2);
            this.tabPage7.Controls.Add(this.comboBoxTPSIT1);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(534, 290);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "TPSIT";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(3, 62);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(69, 25);
            this.label40.TabIndex = 9;
            this.label40.Text = "Voto 2";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(3, 106);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(69, 25);
            this.label39.TabIndex = 8;
            this.label39.Text = "Voto 3";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(3, 150);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(69, 25);
            this.label38.TabIndex = 7;
            this.label38.Text = "Voto 4";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(3, 194);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(69, 25);
            this.label37.TabIndex = 6;
            this.label37.Text = "Voto 5";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(3, 20);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(69, 25);
            this.label36.TabIndex = 5;
            this.label36.Text = "Voto 1";
            // 
            // comboBoxTPSIT5
            // 
            this.comboBoxTPSIT5.FormattingEnabled = true;
            this.comboBoxTPSIT5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxTPSIT5.Location = new System.Drawing.Point(78, 194);
            this.comboBoxTPSIT5.Name = "comboBoxTPSIT5";
            this.comboBoxTPSIT5.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTPSIT5.TabIndex = 4;
            this.comboBoxTPSIT5.Text = "0";
            // 
            // comboBoxTPSIT4
            // 
            this.comboBoxTPSIT4.FormattingEnabled = true;
            this.comboBoxTPSIT4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxTPSIT4.Location = new System.Drawing.Point(78, 150);
            this.comboBoxTPSIT4.Name = "comboBoxTPSIT4";
            this.comboBoxTPSIT4.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTPSIT4.TabIndex = 3;
            this.comboBoxTPSIT4.Text = "0";
            // 
            // comboBoxTPSIT3
            // 
            this.comboBoxTPSIT3.FormattingEnabled = true;
            this.comboBoxTPSIT3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxTPSIT3.Location = new System.Drawing.Point(78, 110);
            this.comboBoxTPSIT3.Name = "comboBoxTPSIT3";
            this.comboBoxTPSIT3.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTPSIT3.TabIndex = 2;
            this.comboBoxTPSIT3.Text = "0";
            // 
            // comboBoxTPSIT2
            // 
            this.comboBoxTPSIT2.FormattingEnabled = true;
            this.comboBoxTPSIT2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxTPSIT2.Location = new System.Drawing.Point(78, 66);
            this.comboBoxTPSIT2.Name = "comboBoxTPSIT2";
            this.comboBoxTPSIT2.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTPSIT2.TabIndex = 1;
            this.comboBoxTPSIT2.Text = "0";
            // 
            // comboBoxTPSIT1
            // 
            this.comboBoxTPSIT1.FormattingEnabled = true;
            this.comboBoxTPSIT1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxTPSIT1.Location = new System.Drawing.Point(78, 20);
            this.comboBoxTPSIT1.Name = "comboBoxTPSIT1";
            this.comboBoxTPSIT1.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTPSIT1.TabIndex = 0;
            this.comboBoxTPSIT1.Text = "0";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.label45);
            this.tabPage8.Controls.Add(this.label44);
            this.tabPage8.Controls.Add(this.label43);
            this.tabPage8.Controls.Add(this.label42);
            this.tabPage8.Controls.Add(this.label41);
            this.tabPage8.Controls.Add(this.comboBoxTele5);
            this.tabPage8.Controls.Add(this.comboBoxTele4);
            this.tabPage8.Controls.Add(this.comboBoxTele3);
            this.tabPage8.Controls.Add(this.comboBoxTele2);
            this.tabPage8.Controls.Add(this.comboBoxTele1);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(534, 290);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Telecomunicazioni";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(3, 61);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(69, 25);
            this.label45.TabIndex = 9;
            this.label45.Text = "Voto 2";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(3, 105);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(69, 25);
            this.label44.TabIndex = 8;
            this.label44.Text = "Voto 3";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(3, 145);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(69, 25);
            this.label43.TabIndex = 7;
            this.label43.Text = "Voto 4";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(3, 184);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(69, 25);
            this.label42.TabIndex = 6;
            this.label42.Text = "Voto 5";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(3, 20);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(69, 25);
            this.label41.TabIndex = 5;
            this.label41.Text = "Voto 1";
            // 
            // comboBoxTele5
            // 
            this.comboBoxTele5.FormattingEnabled = true;
            this.comboBoxTele5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxTele5.Location = new System.Drawing.Point(78, 184);
            this.comboBoxTele5.Name = "comboBoxTele5";
            this.comboBoxTele5.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTele5.TabIndex = 4;
            this.comboBoxTele5.Text = "0";
            // 
            // comboBoxTele4
            // 
            this.comboBoxTele4.FormattingEnabled = true;
            this.comboBoxTele4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxTele4.Location = new System.Drawing.Point(78, 145);
            this.comboBoxTele4.Name = "comboBoxTele4";
            this.comboBoxTele4.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTele4.TabIndex = 3;
            this.comboBoxTele4.Text = "0";
            // 
            // comboBoxTele3
            // 
            this.comboBoxTele3.FormattingEnabled = true;
            this.comboBoxTele3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxTele3.Location = new System.Drawing.Point(78, 105);
            this.comboBoxTele3.Name = "comboBoxTele3";
            this.comboBoxTele3.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTele3.TabIndex = 2;
            this.comboBoxTele3.Text = "0";
            // 
            // comboBoxTele2
            // 
            this.comboBoxTele2.FormattingEnabled = true;
            this.comboBoxTele2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxTele2.Location = new System.Drawing.Point(78, 61);
            this.comboBoxTele2.Name = "comboBoxTele2";
            this.comboBoxTele2.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTele2.TabIndex = 1;
            this.comboBoxTele2.Text = "0";
            // 
            // comboBoxTele1
            // 
            this.comboBoxTele1.FormattingEnabled = true;
            this.comboBoxTele1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxTele1.Location = new System.Drawing.Point(78, 20);
            this.comboBoxTele1.Name = "comboBoxTele1";
            this.comboBoxTele1.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTele1.TabIndex = 0;
            this.comboBoxTele1.Text = "0";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage12);
            this.tabControl1.Location = new System.Drawing.Point(12, 9);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(899, 608);
            this.tabControl1.TabIndex = 34;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.dataGridView1);
            this.tabPage12.Location = new System.Drawing.Point(4, 25);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(891, 579);
            this.tabPage12.TabIndex = 0;
            this.tabPage12.Text = "Registro";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // btn_Cancella
            // 
            this.btn_Cancella.Location = new System.Drawing.Point(1170, 623);
            this.btn_Cancella.Name = "btn_Cancella";
            this.btn_Cancella.Size = new System.Drawing.Size(200, 52);
            this.btn_Cancella.TabIndex = 35;
            this.btn_Cancella.Text = "Cancella";
            this.btn_Cancella.UseVisualStyleBackColor = true;
            this.btn_Cancella.Click += new System.EventHandler(this.btn_Cancella_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1471, 697);
            this.Controls.Add(this.btn_Cancella);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.Italiano);
            this.Controls.Add(this.TxtData);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TxtMatricola);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Txt_Cognome);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_Salva);
            this.Controls.Add(this.btn_Leggi);
            this.Controls.Add(this.TxtClasse);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Aggiungi);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.Italiano.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox TxtClasse;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Aggiungi;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_Leggi;
        private System.Windows.Forms.Button btn_Salva;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Txt_Cognome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtMatricola;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TxtData;
        private System.Windows.Forms.TabControl Italiano;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxIta1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.ComboBox comboBoxIta5;
        private System.Windows.Forms.ComboBox comboBoxIta4;
        private System.Windows.Forms.ComboBox comboBoxIta3;
        private System.Windows.Forms.ComboBox comboBoxIta2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.Button btn_Cancella;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBoxSto2;
        private System.Windows.Forms.ComboBox comboBoxSto3;
        private System.Windows.Forms.ComboBox comboBoxSto4;
        private System.Windows.Forms.ComboBox comboBoxSto5;
        private System.Windows.Forms.ComboBox comboBoxSto1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBoxMate2;
        private System.Windows.Forms.ComboBox comboBoxMate3;
        private System.Windows.Forms.ComboBox comboBoxMate4;
        private System.Windows.Forms.ComboBox comboBoxMate5;
        private System.Windows.Forms.ComboBox comboBoxMate1;
        private System.Windows.Forms.ComboBox comboBoxIng5;
        private System.Windows.Forms.ComboBox comboBoxIng4;
        private System.Windows.Forms.ComboBox comboBoxIng3;
        private System.Windows.Forms.ComboBox comboBoxIng2;
        private System.Windows.Forms.ComboBox comboBoxIng1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox comboBoxInfo5;
        private System.Windows.Forms.ComboBox comboBoxInfo4;
        private System.Windows.Forms.ComboBox comboBoxInfo3;
        private System.Windows.Forms.ComboBox comboBoxInfo2;
        private System.Windows.Forms.ComboBox comboBoxInfo1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox comboBoxSis5;
        private System.Windows.Forms.ComboBox comboBoxSis4;
        private System.Windows.Forms.ComboBox comboBoxSis3;
        private System.Windows.Forms.ComboBox comboBoxSis2;
        private System.Windows.Forms.ComboBox comboBoxSis1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox comboBoxTPSIT5;
        private System.Windows.Forms.ComboBox comboBoxTPSIT4;
        private System.Windows.Forms.ComboBox comboBoxTPSIT3;
        private System.Windows.Forms.ComboBox comboBoxTPSIT2;
        private System.Windows.Forms.ComboBox comboBoxTPSIT1;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox comboBoxTele5;
        private System.Windows.Forms.ComboBox comboBoxTele4;
        private System.Windows.Forms.ComboBox comboBoxTele3;
        private System.Windows.Forms.ComboBox comboBoxTele2;
        private System.Windows.Forms.ComboBox comboBoxTele1;
    }
}

