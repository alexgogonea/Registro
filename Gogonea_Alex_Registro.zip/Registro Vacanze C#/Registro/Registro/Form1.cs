﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json; //json
using System.IO; //contiene file 

namespace Registro
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dataGridView1.ColumnCount = 4;
            dataGridView1.Columns[0].Name = "Matricola";
            dataGridView1.Columns[1].Name = "Nome";
            dataGridView1.Columns[2].Name = "Cognome";
            dataGridView1.Columns[3].Name = "Classe";
            dataGridView1.Columns[3].Name = "Data Nascita";

            dataGridView1.AllowUserToAddRows = false;
            student = new List<Studente>();

        }

        public void Aggiorna()
        {
            dataGridView1.Rows.Clear();
            for (int i = 0; i < student.Count; i++)
            {
                dataGridView1.Rows.Add(student[i].Matricola, student[i].Nome, student[i].Cognome, student[i].Classe, student[i].Data_Nascita);
            }
        }

        List<Studente> student;

        private void btn_Aggiungi_Click(object sender, EventArgs e)
        {
            int IndiceStudente = -1;
            for (int i = 0; i < student.Count; i++)
            {
                if (student[i].Matricola == int.Parse(TxtMatricola.Text))
                {
                    IndiceStudente = i;
                    break;
                }
                
            }
            if (IndiceStudente == -1)
            {
                Studente part = new Studente();
                part.Matricola = int.Parse(TxtMatricola.Text);
                part.Nome = TxtNome.Text;
                part.Cognome = Txt_Cognome.Text;
                part.Classe = TxtClasse.Text;
                part.Data_Nascita = TxtData.Text;
                //Italiano
                part.voti.Italiano[0] = int.Parse(comboBoxIta1.SelectedItem.ToString());
                part.voti.Italiano[1] = int.Parse(comboBoxIta2.SelectedItem.ToString());
                part.voti.Italiano[2] = int.Parse(comboBoxIta3.SelectedItem.ToString());
                part.voti.Italiano[3] = int.Parse(comboBoxIta4.SelectedItem.ToString());
                part.voti.Italiano[4] = int.Parse(comboBoxIta5.SelectedItem.ToString());
                //Storia
                part.voti.Storia[0] = int.Parse(comboBoxSto1.SelectedItem.ToString());
                part.voti.Storia[1] = int.Parse(comboBoxSto2.SelectedItem.ToString());
                part.voti.Storia[2] = int.Parse(comboBoxSto3.SelectedItem.ToString());
                part.voti.Storia[3] = int.Parse(comboBoxSto4.SelectedItem.ToString());
                part.voti.Storia[4] = int.Parse(comboBoxSto5.SelectedItem.ToString());
                //Matematica
                part.voti.Matematica[0] = int.Parse(comboBoxMate1.SelectedItem.ToString());
                part.voti.Matematica[1] = int.Parse(comboBoxMate2.SelectedItem.ToString());
                part.voti.Matematica[2] = int.Parse(comboBoxMate3.SelectedItem.ToString());
                part.voti.Matematica[3] = int.Parse(comboBoxMate4.SelectedItem.ToString());
                part.voti.Matematica[4] = int.Parse(comboBoxMate5.SelectedItem.ToString());
                //Inglese
                part.voti.Inglese[0] = int.Parse(comboBoxIng1.SelectedItem.ToString());
                part.voti.Inglese[1] = int.Parse(comboBoxIng2.SelectedItem.ToString());
                part.voti.Inglese[2] = int.Parse(comboBoxIng3.SelectedItem.ToString());
                part.voti.Inglese[3] = int.Parse(comboBoxIng4.SelectedItem.ToString());
                part.voti.Inglese[4] = int.Parse(comboBoxIng5.SelectedItem.ToString());
                //Informatica
                part.voti.Informatica[0] = int.Parse(comboBoxInfo1.SelectedItem.ToString());
                part.voti.Informatica[1] = int.Parse(comboBoxInfo2.SelectedItem.ToString());
                part.voti.Informatica[2] = int.Parse(comboBoxInfo3.SelectedItem.ToString());
                part.voti.Informatica[3] = int.Parse(comboBoxInfo4.SelectedItem.ToString());
                part.voti.Informatica[4] = int.Parse(comboBoxInfo5.SelectedItem.ToString());
                //Sistemi e reti
                part.voti.Sistemi_e_reti[0] = int.Parse(comboBoxSis1.SelectedItem.ToString());
                part.voti.Sistemi_e_reti[1] = int.Parse(comboBoxSis2.SelectedItem.ToString());
                part.voti.Sistemi_e_reti[2] = int.Parse(comboBoxSis3.SelectedItem.ToString());
                part.voti.Sistemi_e_reti[3] = int.Parse(comboBoxSis4.SelectedItem.ToString());
                part.voti.Sistemi_e_reti[4] = int.Parse(comboBoxSis5.SelectedItem.ToString());
                //TPSIT
                part.voti.TPSIT[0] = int.Parse(comboBoxTPSIT1.SelectedItem.ToString());
                part.voti.TPSIT[1] = int.Parse(comboBoxTPSIT2.SelectedItem.ToString());
                part.voti.TPSIT[2] = int.Parse(comboBoxTPSIT3.SelectedItem.ToString());
                part.voti.TPSIT[3] = int.Parse(comboBoxTPSIT4.SelectedItem.ToString());
                part.voti.TPSIT[4] = int.Parse(comboBoxTPSIT5.SelectedItem.ToString());
                //Telecomunicazioni
                part.voti.Telecomunicazioni[0] = int.Parse(comboBoxTele1.SelectedItem.ToString());
                part.voti.Telecomunicazioni[1] = int.Parse(comboBoxTele2.SelectedItem.ToString());
                part.voti.Telecomunicazioni[2] = int.Parse(comboBoxTele3.SelectedItem.ToString());
                part.voti.Telecomunicazioni[3] = int.Parse(comboBoxTele4.SelectedItem.ToString());
                part.voti.Telecomunicazioni[4] = int.Parse(comboBoxTele5.SelectedItem.ToString());

                student.Add(part);
            }
            else
            {
                student[IndiceStudente].Matricola = int.Parse(TxtMatricola.Text);
                student[IndiceStudente].Nome = TxtNome.Text;
                student[IndiceStudente].Cognome = Txt_Cognome.Text;
                student[IndiceStudente].Classe = TxtClasse.Text;
                student[IndiceStudente].Data_Nascita = TxtData.Text;
                //Italiano
                student[IndiceStudente].voti.Italiano[0] = int.Parse(comboBoxIta1.SelectedItem.ToString());
                student[IndiceStudente].voti.Italiano[1] = int.Parse(comboBoxIta2.SelectedItem.ToString());
                student[IndiceStudente].voti.Italiano[2] = int.Parse(comboBoxIta3.SelectedItem.ToString());
                student[IndiceStudente].voti.Italiano[3] = int.Parse(comboBoxIta4.SelectedItem.ToString());
                student[IndiceStudente].voti.Italiano[4] = int.Parse(comboBoxIta5.SelectedItem.ToString());
                //Storia
                student[IndiceStudente].voti.Storia[0] = int.Parse(comboBoxSto1.SelectedItem.ToString());
                student[IndiceStudente].voti.Storia[1] = int.Parse(comboBoxSto2.SelectedItem.ToString());
                student[IndiceStudente].voti.Storia[2] = int.Parse(comboBoxSto3.SelectedItem.ToString());
                student[IndiceStudente].voti.Storia[3] = int.Parse(comboBoxSto4.SelectedItem.ToString());
                student[IndiceStudente].voti.Storia[4] = int.Parse(comboBoxSto5.SelectedItem.ToString());
                //Matematica
                student[IndiceStudente].voti.Matematica[0] = int.Parse(comboBoxMate1.SelectedItem.ToString());
                student[IndiceStudente].voti.Matematica[1] = int.Parse(comboBoxMate2.SelectedItem.ToString());
                student[IndiceStudente].voti.Matematica[2] = int.Parse(comboBoxMate3.SelectedItem.ToString());
                student[IndiceStudente].voti.Matematica[3] = int.Parse(comboBoxMate4.SelectedItem.ToString());
                student[IndiceStudente].voti.Matematica[4] = int.Parse(comboBoxMate5.SelectedItem.ToString());
                //Inglese
                student[IndiceStudente].voti.Inglese[0] = int.Parse(comboBoxIng1.SelectedItem.ToString());
                student[IndiceStudente].voti.Inglese[1] = int.Parse(comboBoxIng2.SelectedItem.ToString());
                student[IndiceStudente].voti.Inglese[2] = int.Parse(comboBoxIng3.SelectedItem.ToString());
                student[IndiceStudente].voti.Inglese[3] = int.Parse(comboBoxIng4.SelectedItem.ToString());
                student[IndiceStudente].voti.Inglese[4] = int.Parse(comboBoxIng5.SelectedItem.ToString());
                //Informatica
                student[IndiceStudente].voti.Informatica[0] = int.Parse(comboBoxInfo1.SelectedItem.ToString());
                student[IndiceStudente].voti.Informatica[1] = int.Parse(comboBoxInfo2.SelectedItem.ToString());
                student[IndiceStudente].voti.Informatica[2] = int.Parse(comboBoxInfo3.SelectedItem.ToString());
                student[IndiceStudente].voti.Informatica[3] = int.Parse(comboBoxInfo4.SelectedItem.ToString());
                student[IndiceStudente].voti.Informatica[4] = int.Parse(comboBoxInfo5.SelectedItem.ToString());
                //Sistemi e reti
                student[IndiceStudente].voti.Sistemi_e_reti[0] = int.Parse(comboBoxSis1.SelectedItem.ToString());
                student[IndiceStudente].voti.Sistemi_e_reti[1] = int.Parse(comboBoxSis2.SelectedItem.ToString());
                student[IndiceStudente].voti.Sistemi_e_reti[2] = int.Parse(comboBoxSis3.SelectedItem.ToString());
                student[IndiceStudente].voti.Sistemi_e_reti[3] = int.Parse(comboBoxSis4.SelectedItem.ToString());
                student[IndiceStudente].voti.Sistemi_e_reti[4] = int.Parse(comboBoxSis5.SelectedItem.ToString());
                //TPSIT
                student[IndiceStudente].voti.TPSIT[0] = int.Parse(comboBoxTPSIT1.SelectedItem.ToString());
                student[IndiceStudente].voti.TPSIT[1] = int.Parse(comboBoxTPSIT2.SelectedItem.ToString());
                student[IndiceStudente].voti.TPSIT[2] = int.Parse(comboBoxTPSIT3.SelectedItem.ToString());
                student[IndiceStudente].voti.TPSIT[3] = int.Parse(comboBoxTPSIT4.SelectedItem.ToString());
                student[IndiceStudente].voti.TPSIT[4] = int.Parse(comboBoxTPSIT5.SelectedItem.ToString());
                //Telecomunicazioni
                student[IndiceStudente].voti.Telecomunicazioni[0] = int.Parse(comboBoxTele1.SelectedItem.ToString());
                student[IndiceStudente].voti.Telecomunicazioni[1] = int.Parse(comboBoxTele2.SelectedItem.ToString());
                student[IndiceStudente].voti.Telecomunicazioni[2] = int.Parse(comboBoxTele3.SelectedItem.ToString());
                student[IndiceStudente].voti.Telecomunicazioni[3] = int.Parse(comboBoxTele4.SelectedItem.ToString());
                student[IndiceStudente].voti.Telecomunicazioni[4] = int.Parse(comboBoxTele5.SelectedItem.ToString());
            }
            
            //Pulizia campi
            TxtMatricola.Text = "";
            TxtNome.Text = "";
            Txt_Cognome.Text = "";
            TxtClasse.Text = "";
            TxtData.Text = "";
            //Italiano
            comboBoxIta1.Text = "0";
            comboBoxIta2.Text = "0";
            comboBoxIta3.Text = "0";
            comboBoxIta4.Text = "0";
            comboBoxIta5.Text = "0";
            //Storia
            comboBoxSto1.Text = "0";
            comboBoxSto2.Text = "0";
            comboBoxSto3.Text = "0";
            comboBoxSto4.Text = "0";
            comboBoxSto5.Text = "0";
            //Matematica
            comboBoxMate1.Text = "0";
            comboBoxMate2.Text = "0";
            comboBoxMate3.Text = "0";
            comboBoxMate4.Text = "0";
            comboBoxMate5.Text = "0";
            //Inglese
            comboBoxIng1.Text = "0";
            comboBoxIng2.Text = "0";
            comboBoxIng3.Text = "0";
            comboBoxIng4.Text = "0";
            comboBoxIng5.Text = "0";
            //Informatica
            comboBoxInfo1.Text = "0";
            comboBoxInfo2.Text = "0";
            comboBoxInfo3.Text = "0";
            comboBoxInfo4.Text = "0";
            comboBoxInfo5.Text = "0";
            //Sistemi e reti
            comboBoxSis1.Text = "0";
            comboBoxSis2.Text = "0";
            comboBoxSis3.Text = "0";
            comboBoxSis4.Text = "0";
            comboBoxSis5.Text = "0";
            //TPSIT
            comboBoxTPSIT1.Text = "0";
            comboBoxTPSIT2.Text = "0";
            comboBoxTPSIT3.Text = "0";
            comboBoxTPSIT4.Text = "0";
            comboBoxTPSIT5.Text = "0";
            //Telecomunicazioni
            comboBoxTele1.Text = "0";
            comboBoxTele2.Text = "0";
            comboBoxTele3.Text = "0";
            comboBoxTele4.Text = "0";
            comboBoxTele5.Text = "0";

            Aggiorna();
        }

    

   

        private void btn_Salva_Click(object sender, EventArgs e)
        {
            string JsonDati = JsonSerializer.Serialize(student);
            File.WriteAllText("Studenti.Json", JsonDati);
            
        }

        private void btn_Leggi_Click(object sender, EventArgs e)
        {
            string JsonDati = File.ReadAllText("Studenti.Json");
            student = JsonSerializer.Deserialize<List<Studente>>(JsonDati);
            Aggiorna();
        }

        private void btn_Cancella_Click(object sender, EventArgs e)
        {
            int IndiceStudente = -1;
            for (int i = 0; i < student.Count; i++)
            {
                if (student[i].Matricola == int.Parse(TxtMatricola.Text))
                {
                    IndiceStudente = i;
                    break;
                }

            }
            if (IndiceStudente != -1)
            {
                student.RemoveAt(IndiceStudente);
            }
            Aggiorna();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int nRow = e.RowIndex;
            Studente curStudent = student[nRow];
            TxtMatricola.Text = curStudent.Matricola.ToString();
            TxtNome.Text = curStudent.Nome;
            Txt_Cognome.Text = curStudent.Cognome;
            TxtClasse.Text = curStudent.Classe;
            TxtData.Text = curStudent.Data_Nascita;
            //Italiano
            comboBoxIta1.Text = curStudent.voti.Italiano[0].ToString();
            comboBoxIta2.Text = curStudent.voti.Italiano[1].ToString();
            comboBoxIta3.Text = curStudent.voti.Italiano[2].ToString();
            comboBoxIta4.Text = curStudent.voti.Italiano[3].ToString();
            comboBoxIta5.Text = curStudent.voti.Italiano[4].ToString();
            //Storia
            comboBoxSto1.Text = curStudent.voti.Storia[0].ToString();
            comboBoxSto2.Text = curStudent.voti.Storia[1].ToString();
            comboBoxSto3.Text = curStudent.voti.Storia[2].ToString();
            comboBoxSto4.Text = curStudent.voti.Storia[3].ToString();
            comboBoxSto5.Text = curStudent.voti.Storia[4].ToString();
            //Matematica
            comboBoxMate1.Text = curStudent.voti.Matematica[0].ToString();
            comboBoxMate2.Text = curStudent.voti.Matematica[1].ToString();
            comboBoxMate3.Text = curStudent.voti.Matematica[2].ToString();
            comboBoxMate4.Text = curStudent.voti.Matematica[3].ToString();
            comboBoxMate5.Text = curStudent.voti.Matematica[4].ToString();
            //Inglese
            comboBoxIng1.Text = curStudent.voti.Inglese[0].ToString();
            comboBoxIng2.Text = curStudent.voti.Inglese[1].ToString();
            comboBoxIng3.Text = curStudent.voti.Inglese[2].ToString();
            comboBoxIng4.Text = curStudent.voti.Inglese[3].ToString();
            comboBoxIng5.Text = curStudent.voti.Inglese[4].ToString();
            //Informatica
            comboBoxInfo1.Text = curStudent.voti.Informatica[0].ToString();
            comboBoxInfo2.Text = curStudent.voti.Informatica[1].ToString();
            comboBoxInfo3.Text = curStudent.voti.Informatica[2].ToString();
            comboBoxInfo4.Text = curStudent.voti.Informatica[3].ToString();
            comboBoxInfo5.Text = curStudent.voti.Informatica[4].ToString();
            //Sistemi e reti
            comboBoxSis1.Text = curStudent.voti.Sistemi_e_reti[0].ToString();
            comboBoxSis2.Text = curStudent.voti.Sistemi_e_reti[1].ToString();
            comboBoxSis3.Text = curStudent.voti.Sistemi_e_reti[2].ToString();
            comboBoxSis4.Text = curStudent.voti.Sistemi_e_reti[3].ToString();
            comboBoxSis5.Text = curStudent.voti.Sistemi_e_reti[4].ToString();
            //TPSIT
            comboBoxTPSIT1.Text = curStudent.voti.TPSIT[0].ToString();
            comboBoxTPSIT2.Text = curStudent.voti.TPSIT[1].ToString();
            comboBoxTPSIT3.Text = curStudent.voti.TPSIT[2].ToString();
            comboBoxTPSIT4.Text = curStudent.voti.TPSIT[3].ToString();
            comboBoxTPSIT5.Text = curStudent.voti.TPSIT[4].ToString();
            //Telecomunicazioni
            comboBoxTele1.Text = curStudent.voti.Telecomunicazioni[0].ToString();
            comboBoxTele2.Text = curStudent.voti.Telecomunicazioni[1].ToString();
            comboBoxTele3.Text = curStudent.voti.Telecomunicazioni[2].ToString();
            comboBoxTele4.Text = curStudent.voti.Telecomunicazioni[3].ToString();
            comboBoxTele5.Text = curStudent.voti.Telecomunicazioni[4].ToString();
        }
    }

    public class Voti
    {
        public int[] Italiano = new int[5];
        public int[] Storia = new int[5];
        public int[] Matematica = new int[5];
        public int[] Inglese = new int[5];
        public int[] Informatica = new int[5];
        public int[] Sistemi_e_reti = new int[5];
        public int[] TPSIT = new int[5];
        public int[] Telecomunicazioni = new int[5];

        public Voti()//costruttore in C#
        {
            for (int i = 0; i < 5; i++)
            {
                Italiano[i] = 0;
                Storia[i] = 0;
                Matematica[i] = 0;
                Inglese[i] = 0;
                Informatica[i] = 0;
                Sistemi_e_reti[i] = 0;
                TPSIT[i] = 0;
                Telecomunicazioni[i] = 0;
            }

        }
    }

  
    public class Studente
    {
        public int Matricola { get; set; }
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public string Data_Nascita { get; set; }
        public string Classe { get; set; }

        public Voti voti = new Voti();
        
    }
}

